#pragma once

using namespace std;

class Point
{
private:
public:
	int xCoord;
	int yCoord;
	Point();
	Point(int x, int y);
};