
// Includes
#include "Shape.h";
#include "Point.h";

using namespace std;

Shape::Shape() {}

vector<Point> Shape::calculatePoints() { return vector<Point>(); };

float Shape::calculateArea() { return NULL; };

float Shape::calculatePerimeter() { return NULL; };

string Shape::toString() { return NULL; };
