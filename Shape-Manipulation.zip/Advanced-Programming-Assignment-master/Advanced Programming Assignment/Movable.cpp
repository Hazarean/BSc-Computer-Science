#include "Movable.h"

using namespace std;

Movable::Movable() {};

void Movable::move(int newX, int newY) {};

void Movable::scale(float scaleX, float scaleY) {};

void Movable::scale(float scaleF) {};