#include "Point.h"

using namespace std;

Point::Point() {};

Point::Point(int x = 0, int y = 0) {
	xCoord = x;
	yCoord = y;
}